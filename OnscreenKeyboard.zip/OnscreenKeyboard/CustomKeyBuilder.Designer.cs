﻿
namespace Oskeyboard
{
	partial class CustomKeyBuilder
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.checkBox1 = new System.Windows.Forms.CheckBox();
			this.textCustom1 = new System.Windows.Forms.TextBox();
			this.textCustom2 = new System.Windows.Forms.TextBox();
			this.checkBox2 = new System.Windows.Forms.CheckBox();
			this.textCustom3 = new System.Windows.Forms.TextBox();
			this.checkBox3 = new System.Windows.Forms.CheckBox();
			this.textCustom4 = new System.Windows.Forms.TextBox();
			this.checkBox4 = new System.Windows.Forms.CheckBox();
			this.textCustom5 = new System.Windows.Forms.TextBox();
			this.checkBox5 = new System.Windows.Forms.CheckBox();
			this.textCustom10 = new System.Windows.Forms.TextBox();
			this.checkBox6 = new System.Windows.Forms.CheckBox();
			this.textCustom9 = new System.Windows.Forms.TextBox();
			this.checkBox7 = new System.Windows.Forms.CheckBox();
			this.textCustom8 = new System.Windows.Forms.TextBox();
			this.checkBox8 = new System.Windows.Forms.CheckBox();
			this.textCustom7 = new System.Windows.Forms.TextBox();
			this.checkBox9 = new System.Windows.Forms.CheckBox();
			this.textCustom6 = new System.Windows.Forms.TextBox();
			this.checkBox10 = new System.Windows.Forms.CheckBox();
			this.button67 = new System.Windows.Forms.Button();
			this.button1 = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// checkBox1
			// 
			this.checkBox1.AutoSize = true;
			this.checkBox1.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.checkBox1.Location = new System.Drawing.Point(12, 12);
			this.checkBox1.Name = "checkBox1";
			this.checkBox1.Size = new System.Drawing.Size(120, 21);
			this.checkBox1.TabIndex = 0;
			this.checkBox1.Text = "Custom Key 1";
			this.checkBox1.UseVisualStyleBackColor = true;
			this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
			// 
			// textCustom1
			// 
			this.textCustom1.Enabled = false;
			this.textCustom1.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textCustom1.Location = new System.Drawing.Point(153, 9);
			this.textCustom1.Name = "textCustom1";
			this.textCustom1.Size = new System.Drawing.Size(161, 25);
			this.textCustom1.TabIndex = 1;
			// 
			// textCustom2
			// 
			this.textCustom2.Enabled = false;
			this.textCustom2.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textCustom2.Location = new System.Drawing.Point(153, 50);
			this.textCustom2.Name = "textCustom2";
			this.textCustom2.Size = new System.Drawing.Size(161, 25);
			this.textCustom2.TabIndex = 3;
			// 
			// checkBox2
			// 
			this.checkBox2.AutoSize = true;
			this.checkBox2.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.checkBox2.Location = new System.Drawing.Point(12, 53);
			this.checkBox2.Name = "checkBox2";
			this.checkBox2.Size = new System.Drawing.Size(120, 21);
			this.checkBox2.TabIndex = 2;
			this.checkBox2.Text = "Custom Key 2";
			this.checkBox2.UseVisualStyleBackColor = true;
			this.checkBox2.CheckedChanged += new System.EventHandler(this.checkBox2_CheckedChanged);
			// 
			// textCustom3
			// 
			this.textCustom3.Enabled = false;
			this.textCustom3.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textCustom3.Location = new System.Drawing.Point(153, 91);
			this.textCustom3.Name = "textCustom3";
			this.textCustom3.Size = new System.Drawing.Size(161, 25);
			this.textCustom3.TabIndex = 5;
			// 
			// checkBox3
			// 
			this.checkBox3.AutoSize = true;
			this.checkBox3.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.checkBox3.Location = new System.Drawing.Point(12, 94);
			this.checkBox3.Name = "checkBox3";
			this.checkBox3.Size = new System.Drawing.Size(120, 21);
			this.checkBox3.TabIndex = 4;
			this.checkBox3.Text = "Custom Key 3";
			this.checkBox3.UseVisualStyleBackColor = true;
			this.checkBox3.CheckedChanged += new System.EventHandler(this.checkBox3_CheckedChanged);
			// 
			// textCustom4
			// 
			this.textCustom4.Enabled = false;
			this.textCustom4.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textCustom4.Location = new System.Drawing.Point(153, 132);
			this.textCustom4.Name = "textCustom4";
			this.textCustom4.Size = new System.Drawing.Size(161, 25);
			this.textCustom4.TabIndex = 7;
			// 
			// checkBox4
			// 
			this.checkBox4.AutoSize = true;
			this.checkBox4.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.checkBox4.Location = new System.Drawing.Point(12, 135);
			this.checkBox4.Name = "checkBox4";
			this.checkBox4.Size = new System.Drawing.Size(120, 21);
			this.checkBox4.TabIndex = 6;
			this.checkBox4.Text = "Custom Key 4";
			this.checkBox4.UseVisualStyleBackColor = true;
			this.checkBox4.CheckedChanged += new System.EventHandler(this.checkBox4_CheckedChanged);
			// 
			// textCustom5
			// 
			this.textCustom5.Enabled = false;
			this.textCustom5.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textCustom5.Location = new System.Drawing.Point(153, 173);
			this.textCustom5.Name = "textCustom5";
			this.textCustom5.Size = new System.Drawing.Size(161, 25);
			this.textCustom5.TabIndex = 9;
			// 
			// checkBox5
			// 
			this.checkBox5.AutoSize = true;
			this.checkBox5.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.checkBox5.Location = new System.Drawing.Point(12, 176);
			this.checkBox5.Name = "checkBox5";
			this.checkBox5.Size = new System.Drawing.Size(120, 21);
			this.checkBox5.TabIndex = 8;
			this.checkBox5.Text = "Custom Key 5";
			this.checkBox5.UseVisualStyleBackColor = true;
			this.checkBox5.CheckedChanged += new System.EventHandler(this.checkBox5_CheckedChanged);
			// 
			// textCustom10
			// 
			this.textCustom10.Enabled = false;
			this.textCustom10.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textCustom10.Location = new System.Drawing.Point(479, 173);
			this.textCustom10.Name = "textCustom10";
			this.textCustom10.Size = new System.Drawing.Size(161, 25);
			this.textCustom10.TabIndex = 19;
			// 
			// checkBox6
			// 
			this.checkBox6.AutoSize = true;
			this.checkBox6.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.checkBox6.Location = new System.Drawing.Point(338, 11);
			this.checkBox6.Name = "checkBox6";
			this.checkBox6.Size = new System.Drawing.Size(120, 21);
			this.checkBox6.TabIndex = 18;
			this.checkBox6.Text = "Custom Key 6";
			this.checkBox6.UseVisualStyleBackColor = true;
			this.checkBox6.CheckedChanged += new System.EventHandler(this.checkBox6_CheckedChanged);
			// 
			// textCustom9
			// 
			this.textCustom9.Enabled = false;
			this.textCustom9.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textCustom9.Location = new System.Drawing.Point(479, 132);
			this.textCustom9.Name = "textCustom9";
			this.textCustom9.Size = new System.Drawing.Size(161, 25);
			this.textCustom9.TabIndex = 17;
			// 
			// checkBox7
			// 
			this.checkBox7.AutoSize = true;
			this.checkBox7.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.checkBox7.Location = new System.Drawing.Point(338, 50);
			this.checkBox7.Name = "checkBox7";
			this.checkBox7.Size = new System.Drawing.Size(120, 21);
			this.checkBox7.TabIndex = 16;
			this.checkBox7.Text = "Custom Key 7";
			this.checkBox7.UseVisualStyleBackColor = true;
			this.checkBox7.CheckedChanged += new System.EventHandler(this.checkBox7_CheckedChanged);
			// 
			// textCustom8
			// 
			this.textCustom8.Enabled = false;
			this.textCustom8.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textCustom8.Location = new System.Drawing.Point(479, 91);
			this.textCustom8.Name = "textCustom8";
			this.textCustom8.Size = new System.Drawing.Size(161, 25);
			this.textCustom8.TabIndex = 15;
			// 
			// checkBox8
			// 
			this.checkBox8.AutoSize = true;
			this.checkBox8.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.checkBox8.Location = new System.Drawing.Point(338, 94);
			this.checkBox8.Name = "checkBox8";
			this.checkBox8.Size = new System.Drawing.Size(120, 21);
			this.checkBox8.TabIndex = 14;
			this.checkBox8.Text = "Custom Key 8";
			this.checkBox8.UseVisualStyleBackColor = true;
			this.checkBox8.CheckedChanged += new System.EventHandler(this.checkBox8_CheckedChanged);
			// 
			// textCustom7
			// 
			this.textCustom7.Enabled = false;
			this.textCustom7.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textCustom7.Location = new System.Drawing.Point(479, 50);
			this.textCustom7.Name = "textCustom7";
			this.textCustom7.Size = new System.Drawing.Size(161, 25);
			this.textCustom7.TabIndex = 13;
			// 
			// checkBox9
			// 
			this.checkBox9.AutoSize = true;
			this.checkBox9.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.checkBox9.Location = new System.Drawing.Point(338, 132);
			this.checkBox9.Name = "checkBox9";
			this.checkBox9.Size = new System.Drawing.Size(120, 21);
			this.checkBox9.TabIndex = 12;
			this.checkBox9.Text = "Custom Key 9";
			this.checkBox9.UseVisualStyleBackColor = true;
			this.checkBox9.CheckedChanged += new System.EventHandler(this.checkBox9_CheckedChanged);
			// 
			// textCustom6
			// 
			this.textCustom6.Enabled = false;
			this.textCustom6.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textCustom6.Location = new System.Drawing.Point(479, 9);
			this.textCustom6.Name = "textCustom6";
			this.textCustom6.Size = new System.Drawing.Size(161, 25);
			this.textCustom6.TabIndex = 11;
			// 
			// checkBox10
			// 
			this.checkBox10.AutoSize = true;
			this.checkBox10.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.checkBox10.Location = new System.Drawing.Point(338, 173);
			this.checkBox10.Name = "checkBox10";
			this.checkBox10.Size = new System.Drawing.Size(128, 21);
			this.checkBox10.TabIndex = 10;
			this.checkBox10.Text = "Custom Key 10";
			this.checkBox10.UseVisualStyleBackColor = true;
			this.checkBox10.CheckedChanged += new System.EventHandler(this.checkBox10_CheckedChanged);
			// 
			// button67
			// 
			this.button67.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
			this.button67.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button67.FlatAppearance.BorderSize = 0;
			this.button67.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(118)))), ((int)(((byte)(215)))));
			this.button67.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(118)))), ((int)(((byte)(215)))));
			this.button67.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.button67.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button67.ForeColor = System.Drawing.Color.White;
			this.button67.Location = new System.Drawing.Point(186, 229);
			this.button67.Margin = new System.Windows.Forms.Padding(2);
			this.button67.Name = "button67";
			this.button67.Size = new System.Drawing.Size(116, 41);
			this.button67.TabIndex = 85;
			this.button67.Text = "Save";
			this.button67.UseVisualStyleBackColor = false;
			this.button67.Click += new System.EventHandler(this.button67_Click);
			// 
			// button1
			// 
			this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
			this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button1.FlatAppearance.BorderSize = 0;
			this.button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(118)))), ((int)(((byte)(215)))));
			this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(118)))), ((int)(((byte)(215)))));
			this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.button1.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button1.ForeColor = System.Drawing.Color.White;
			this.button1.Location = new System.Drawing.Point(342, 229);
			this.button1.Margin = new System.Windows.Forms.Padding(2);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(116, 41);
			this.button1.TabIndex = 86;
			this.button1.Text = "Exit";
			this.button1.UseVisualStyleBackColor = false;
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// CustomKeyBuilder
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(656, 281);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.button67);
			this.Controls.Add(this.textCustom10);
			this.Controls.Add(this.checkBox6);
			this.Controls.Add(this.textCustom9);
			this.Controls.Add(this.checkBox7);
			this.Controls.Add(this.textCustom8);
			this.Controls.Add(this.checkBox8);
			this.Controls.Add(this.textCustom7);
			this.Controls.Add(this.checkBox9);
			this.Controls.Add(this.textCustom6);
			this.Controls.Add(this.checkBox10);
			this.Controls.Add(this.textCustom5);
			this.Controls.Add(this.checkBox5);
			this.Controls.Add(this.textCustom4);
			this.Controls.Add(this.checkBox4);
			this.Controls.Add(this.textCustom3);
			this.Controls.Add(this.checkBox3);
			this.Controls.Add(this.textCustom2);
			this.Controls.Add(this.checkBox2);
			this.Controls.Add(this.textCustom1);
			this.Controls.Add(this.checkBox1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.Name = "CustomKeyBuilder";
			this.ShowIcon = false;
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "CustomKeyBuilder";
			this.TopMost = true;
			this.Load += new System.EventHandler(this.CustomKeyBuilder_Load);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.CheckBox checkBox1;
		private System.Windows.Forms.TextBox textCustom1;
		private System.Windows.Forms.TextBox textCustom2;
		private System.Windows.Forms.CheckBox checkBox2;
		private System.Windows.Forms.TextBox textCustom3;
		private System.Windows.Forms.CheckBox checkBox3;
		private System.Windows.Forms.TextBox textCustom4;
		private System.Windows.Forms.CheckBox checkBox4;
		private System.Windows.Forms.TextBox textCustom5;
		private System.Windows.Forms.CheckBox checkBox5;
		private System.Windows.Forms.TextBox textCustom10;
		private System.Windows.Forms.CheckBox checkBox6;
		private System.Windows.Forms.TextBox textCustom9;
		private System.Windows.Forms.CheckBox checkBox7;
		private System.Windows.Forms.TextBox textCustom8;
		private System.Windows.Forms.CheckBox checkBox8;
		private System.Windows.Forms.TextBox textCustom7;
		private System.Windows.Forms.CheckBox checkBox9;
		private System.Windows.Forms.TextBox textCustom6;
		private System.Windows.Forms.CheckBox checkBox10;
		private System.Windows.Forms.Button button67;
		private System.Windows.Forms.Button button1;
	}
}